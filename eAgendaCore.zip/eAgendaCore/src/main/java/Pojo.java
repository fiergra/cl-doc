

public class Pojo {

	public String s;
	public Integer i;
	public Pojo2 pojo;

	protected Pojo() {}
	
	public Pojo(String s, Integer i, Pojo2 pojo2) {
		this.s = s;
		this.i = i;
		this.pojo = pojo2;
	}
	
	
}
