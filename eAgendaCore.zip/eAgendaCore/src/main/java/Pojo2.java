

public class Pojo2 {

	public String s;
	public Integer i;

	protected Pojo2() {}
	
	public Pojo2(String s, Integer i) {
		this.s = s;
		this.i = i;
	}
	
	
}
